package com.demo.service;

import java.util.List;

import com.demo.model.Menu;


public interface MenuService {
	
	

	public Menu saveMenu(Menu menu);
	
	public Menu getById(int id);
	
	public List getAllMenu();

	public void deleteMenuById(int id);
	
	

	

	public void deleteAll();

}
