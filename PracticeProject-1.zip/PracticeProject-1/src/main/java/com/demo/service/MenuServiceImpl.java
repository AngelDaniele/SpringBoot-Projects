package com.demo.service;

import java.lang.annotation.Annotation;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.model.Menu;
import com.demo.repository.MenuRepository;
import org.springframework.stereotype.Service;
@Service
public class MenuServiceImpl implements MenuService{
	
	@Autowired
	MenuRepository menuRepository;

	@Override
	public Menu saveMenu(Menu menu) {
		
		return menuRepository.save(menu);
	}

	@Override
	public Menu getById(int id) {
		// TODO Auto-generated method stub
		return menuRepository.getById(id);
	}

	@Override
	public List getAllMenu() {
		// TODO Auto-generated method stub
		return menuRepository.findAll();
	}

	

	@Override
	public void deleteMenuById(int id) {
		
		menuRepository.deleteById(id);
		
	}
	
	public void deleteAll()
	{
		menuRepository.deleteAll();
	}

	


	

}
