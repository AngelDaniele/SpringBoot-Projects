package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Menu;
import com.demo.service.MenuService;

@RestController
@RequestMapping("/Menu")
public class MenuController {
	
	@Autowired
	MenuService menuService;
	

	@PostMapping("/savemenu")
	public ResponseEntity<Menu> saveMenu(@RequestBody Menu menu)
	{
	     return new ResponseEntity<Menu>(menuService.saveMenu(menu),HttpStatus.CREATED);	
	}
	
	
	@GetMapping("/{food_id}")
	public ResponseEntity<Menu> getById(@PathVariable("food_id")int id)
	{
		return new ResponseEntity<Menu>(menuService.getById( id),HttpStatus.OK);
	}
	
	
   @GetMapping("/getAllMenu")
   public List<Menu> getAllMenu()
   {
	   return menuService.getAllMenu();
   }
   
   
   @DeleteMapping("/delete/{food_int}")
   public ResponseEntity<String> deleteMenuById(@PathVariable ("food_int")int id) {
	   menuService.deleteMenuById(id);
	   return new ResponseEntity<String>( "Deleted Successsfully",HttpStatus.OK);
	   
	   
   }
   
   @DeleteMapping("/deleteAll")
   public ResponseEntity<String> deleteAllMenu()
   {
	  menuService.deleteAll();
	   return  new ResponseEntity<String>("Deleted Sucessfully",HttpStatus.OK);
   }
   
   
   

}
