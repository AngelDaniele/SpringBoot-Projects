package com.example.scm;

import com.example.scm.model.Product;
import com.example.scm.repository.ProductRepository;
import com.example.scm.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class SCMGetProductByIdServiceTests {

	//@Autowired
	@InjectMocks
	ProductService productService;

	@MockBean
	ProductRepository productRepository;

	@BeforeEach
	void setup(){
       Optional<Product> product1 = Optional.of(new Product(4,"Apple iPhone23","138.7 cm (55 inches) U Series 4K(Black)","Electronics",1227 ,767 ,18,10,40999,30,34000,0,8734,"32",4));
	Mockito.when(productRepository.findById(4)).thenReturn(product1);

	}

	@Test
	public void getProductById_Success() {

	   String productName = "Apple iPhone23";

       Optional<Product> product2= productService.getProductById(4);
		assertEquals(productName,product2.get().getProductName());
   }

















		}
