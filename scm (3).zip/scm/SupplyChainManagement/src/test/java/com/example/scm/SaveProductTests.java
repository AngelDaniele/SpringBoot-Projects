package com.example.scm;

import com.example.scm.model.Product;
import com.example.scm.repository.ProductRepository;
import com.example.scm.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
public class SaveProductTests {




    @InjectMocks
    private ProductService productService;

    @Mock
    private ProductRepository productRepository;

    @BeforeEach
    void setup() {


        }

    @Test
    public void createProduct_Success() {

        Product newProduct = new Product(5, "Samsung Galaxy S22", "6.7 inches AMOLED Display", "Electronics", 1000, 800, 20, 15, 899, 50, 750, 0, 4321, "64", 5);
        when(productRepository.save(any(Product.class))).thenReturn(newProduct);
        Product createdProduct = productService.saveProduct(newProduct);
        assertEquals(newProduct.getProductName(), createdProduct.getProductName());
    }




}
