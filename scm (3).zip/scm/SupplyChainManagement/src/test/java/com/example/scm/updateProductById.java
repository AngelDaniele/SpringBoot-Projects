//package com.example.scm;
//
//import com.example.scm.model.Product;
//import com.example.scm.repository.ProductRepository;
//import com.example.scm.service.ProductService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//@SpringBootTest
//public class updateProductById
//{
//
//  @Autowired
//  ProductService productservice;
//
//  @MockBean
//    ProductRepository productRepository;
//
//
//
////  @BeforeEach
////    void setUp(){
////      Optional<Product> product1 = Optional.of(new Product(4,"Apple iPhone23","138.7 cm (55 inches) U Series 4K(Black)","Electronics",1227 ,767 ,18,10,40999,30,34000,0,8734,"32",4));
////      Mockito.when(productRepository.updateProductById(product1))thenReturn();
////
////  }
//
//
//
//// ...
//
//    @BeforeEach
//    void setUp() {
//
//
//        // Create an instance of the product you want to update with
//        Product updatedProduct = new Product(4, "New Name", "New Description", "New Category", 999.99, /* other properties */);
//
//        // Mock the behavior of the repository's findById method
//        when(productRepository.findById(4)).thenReturn(Optional.of(updatedProduct));
//
//        // Mock the behavior of the repository's save method
//        when(productRepository.save(any())).thenReturn(updatedProduct);
//
//        productservice.productRepository = productRepository; // Inject the mock repository into the service
//        productservice = spy(productservice); // Spy on the service (optional, allows you to verify method calls)
//    }
//
//    @Test
//    void testUpdateProduct() {
//        Product updateProduct = new Product(4, "New Name", "New Description", "New Category", 999.99, /* other properties */);
//        Product result = productservice.updateProduct(updateProduct, 4);
//
//        // Assertions or verifications can be done here
//        assertEquals(updateProduct.getProductName(), result.getProductName());
//        assertEquals(updateProduct.getProductDescription(), result.getProductDescription());
//        // ... other assertions ...
//
//        verify(productRepository, times(1)).findById(4); // Verify findById was called once
//        verify(productRepository, times(1)).save(any()); // Verify save was called once with any argument
//    }
//
//
//
//
//
//
//}
