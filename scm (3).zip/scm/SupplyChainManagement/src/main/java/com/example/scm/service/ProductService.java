package com.example.scm.service;
import com.example.scm.model.Product;
import com.example.scm.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
@Transactional
public class ProductService {
    @Autowired
    public ProductRepository productRepository;

    public Product saveProduct(Product product) {

        return productRepository.save(product);

    }

    public  List<Product> getAllProduct() {
        return productRepository.findAll();
    }

    public Product findProductByNameAndCategory(String productName,String productCategory) {
          return productRepository.findByProductNameAndProductCategory(productName,productCategory);


    }














    public Product findProductByName(String productName)
    {
        return productRepository.findByProductName(productName);
    }

   public List<Product> findProductByCategory(String productCategory)
    {
        return productRepository.findByProductCategory(productCategory);
   }



    public void removeProductById (Integer productid)
    {
        productRepository.deleteById (productid);


    }

    public void removeProductByName (String productName)

    {
         productRepository.deleteByProductName(productName);


    }


    public  Optional<Product> getProductById(Integer productid)

    {

        return productRepository.findById(productid);
    }


    public Product updateProduct(Product updateProduct, int key) {
        Optional<Product> existingProductOptional = productRepository.findById(key);

        if (existingProductOptional.isPresent()) {
            Product existingProduct = existingProductOptional.get();
            existingProduct.setProductName(updateProduct.getProductName());
            existingProduct.setPricePerQuantity(updateProduct.getPricePerQuantity());

            return productRepository.save(existingProduct);
        } else {
            throw new NoSuchElementException("Product not found with key: " + key);
        }
    }

}

























