package com.example.scm.controller;

import com.example.scm.model.Product;
import com.example.scm.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/Product")
public class ProductController {

    @Autowired
    ProductService productService;

    @PostMapping("/saveProduct")
    public Product saveProudct(@RequestBody Product product) {
        return productService.saveProduct(product);
    }


    @GetMapping("/getAllProduct")
    public List<Product> getProducts() {
        return productService.getAllProduct();


    }


    @GetMapping("/findById/{productid}")
    public Optional<Product> getProductById(@PathVariable("productid") Integer productid) {
        return productService.getProductById(productid);
    }



    @GetMapping("/findProductByName/{productName}/{productCategory}")
    public ResponseEntity<Product>getProductByNameAndCategory(@PathVariable("productName") String productName,@PathVariable("productCategory") String productCategory ){
        Product getProductByNameAndCategory=productService.findProductByNameAndCategory(productName, productCategory);
        return new ResponseEntity<Product>(getProductByNameAndCategory,HttpStatus.ACCEPTED);
    }


    @GetMapping("/getProductByName/{productName}")
    public ResponseEntity<Product>getProductByName(@PathVariable("productName") String productName)
    {
        Product getProductName = productService.findProductByName(productName);
        return new ResponseEntity<Product>(getProductName,HttpStatus.OK);
    }

    @GetMapping("/getProductByCategory/{productCategory}")
    public ResponseEntity<List<Product>>getProductByCategory(@PathVariable("productCategory") String productCategory)
    {
       List<Product> getProductCategory = productService.findProductByCategory(productCategory);
        return new ResponseEntity((List<Product>) getProductCategory,HttpStatus.OK);
   }


    @DeleteMapping("/removeProductById/{productid}")
    public String removeProduct(@PathVariable("productid") Integer productid) {
        productService.removeProductById(productid);
        return "product Id " + productid + " removed Successfully";


    }


      @DeleteMapping("removeProductByName/{productName}")
       public ResponseEntity<String> removeProductByName(@PathVariable("productName") String productName)
        {
            productService.removeProductByName(productName);
            return new ResponseEntity<String>(productName +"deleted Successfully",HttpStatus.OK) ;


        }


    @PutMapping("/updateProduct/{key}")
   public ResponseEntity<Product> updateProduct(@Validated @RequestBody Product product,@PathVariable int key )
    {
      Product updateProduct = productService.updateProduct(product,key);
              return new ResponseEntity<Product>(updateProduct,HttpStatus.ACCEPTED);

    }











}

