package com.example.scm.model;

import javax.persistence.*;
import java.util.Iterator;

@Entity
@Table(name="Product")

public class Product  {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    public int productid;

    public String productName;

    public String productDescription;

    public String productCategory;

    public float productHeight;

    public float productWidth;

    public float productWeight;

    public long quantity;

    public long pricePerQuantity;

    public int discount;

    public int discountPricePerQuantity;

    public long taxCode;

    public int expiryDate;

    public String barCode;

    public long serialNumber;


    public Product(){

    }

    public Product(int productid, String productName, String productDescription, String productCategory, float productHeight, float productWidth, float productWeight, long quantity, long pricePerQuantity, int discount, int discountPricePerQuantity, long taxCode, int expiryDate, String barCode, long serialNumber) {
        this.productid = productid;
        this.productName = productName;
        this.productDescription = productDescription;
        this.productCategory = productCategory;
        this.productHeight = productHeight;
        this.productWidth = productWidth;
        this.productWeight = productWeight;
        this.quantity = quantity;
        this.pricePerQuantity = pricePerQuantity;
        this.discount = discount;
        this.discountPricePerQuantity = discountPricePerQuantity;
        this.taxCode = taxCode;
        this.expiryDate = expiryDate;
        this.barCode = barCode;
        this.serialNumber = serialNumber;
    }

    public Product(String s, String s1, String electronics, double v, double v1, int i, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
    }

//    @Override
//    public String toString() {
//        return "Product{" +
//                "productid=" + productid +
//                ", productName='" + productName + '\'' +
//                ", productDescription='" + productDescription + '\'' +
//                ", productCategory='" + productCategory + '\'' +
//                ", productHeight=" + productHeight +
//                ", productWidth=" + productWidth +
//                ", productWeight=" + productWeight +
//                ", quantity=" + quantity +
//                ", pricePerQuantity=" + pricePerQuantity +
//                ", discount=" + discount +
//                ", discountPricePerQuantity=" + discountPricePerQuantity +
//                ", taxCode=" + taxCode +
//                ", expiryDate=" + expiryDate +
//                ", barCode='" + barCode + '\'' +
//                ", serialNumber=" + serialNumber +
//                '}';
  //  }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductid() {
        return productid;
    }

    public void setProductid(int productid) {
        this.productid = productid;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public float getProductHeight() {
        return productHeight;
    }

    public void setProductHeight(float productHeight) {
        this.productHeight = productHeight;
    }

    public float getProductWidth() {
        return productWidth;
    }

    public void setProductWidth(float productWidth) {
        this.productWidth = productWidth;
    }

    public float getProductWeight() {
        return productWeight;
    }

    public void setProductWeight(float productWeight) {
        this.productWeight = productWeight;
    }

    public long getQuantity() {
        return quantity;
    }

    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    public long getPricePerQuantity() {
        return pricePerQuantity;
    }

    public void setPricePerQuantity(long pricePerQuantity) {
        this.pricePerQuantity = pricePerQuantity;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public int getDiscountPricePerQuantity() {
        return discountPricePerQuantity;
    }

    public void setDiscountPricePerQuantity(int discountPricePerQuantity) {
        this.discountPricePerQuantity = discountPricePerQuantity;
    }

    public long getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(long taxCode) {
        this.taxCode = taxCode;
    }

    public int getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(int expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }


    public long getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(long serialNumber) {
        this.serialNumber = serialNumber;
    }



    }
