package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.Product;
import com.edubridge.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;
	
	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(int product_id) {
		// TODO Auto-generated method stub
		return productRepository.findById(product_id).get();
	}

	@Override
	public void removeProduct(int product_id) {
		// TODO Auto-generated method stub
		productRepository.deleteById(product_id);
	}

}
