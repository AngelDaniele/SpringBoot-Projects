package com.edubridge.service;

import java.util.List;

import com.edubridge.model.User;

public interface UserService {

	User registerUser(User user);
	List<User> getAllUsers();
}
