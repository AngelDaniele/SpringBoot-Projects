package com.edubridge.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.edubridge.model.User;
import com.edubridge.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User registerUser(User user) //data from postman username,password,role
	{
		// TODO Auto-generated method stub
		BCryptPasswordEncoder bcrypt=new BCryptPasswordEncoder();
		String enPassWrd=bcrypt.encode(user.getPassword());
		user.setPassword(enPassWrd);
		return userRepository.save(user);//encrypted password 
	}

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	
}
