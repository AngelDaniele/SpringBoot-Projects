package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Product;
import com.edubridge.model.User;
import com.edubridge.service.UserService;

//@RestController
@RequestMapping("/")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping
	public ResponseEntity<User> saveUser(@RequestBody User user)
	{
		System.out.println("user"+user);
return new ResponseEntity<User>(userService.registerUser(user),HttpStatus.CREATED);	
	}
	@GetMapping("admin")
	public List<User> getAllProducts()
	{
		System.out.println("get users");
		return userService.getAllUsers();
	}

}
