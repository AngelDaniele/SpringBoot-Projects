package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Product;

public interface ProductService {
	
	public Product saveProduct(Product product);
	public List<Product> getAllProducts();
	public Product getProductById(int product_id);
	public void removeProduct(int product_id);
	
	
}
