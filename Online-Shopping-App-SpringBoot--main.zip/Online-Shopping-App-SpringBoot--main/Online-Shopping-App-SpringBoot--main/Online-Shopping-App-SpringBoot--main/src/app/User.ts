export class User {
    
       UserId!:number;
       name!: string;
       mobile!: string;
       password!: string;
       role!: string;
  
  }

 