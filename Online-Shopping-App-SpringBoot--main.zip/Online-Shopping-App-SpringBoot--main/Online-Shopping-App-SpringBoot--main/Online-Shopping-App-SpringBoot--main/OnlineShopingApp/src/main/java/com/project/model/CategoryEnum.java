package com.project.model;

public enum CategoryEnum {
		
	MOBILES,LAPTOP,TABLET,SMARTTV,CAMERA
}
 