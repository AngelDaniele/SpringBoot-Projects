package com.demo.service;

import com.demo.entity.Student;

public interface StudentService {
	
	public Student saveStudent(Student student);

}
