package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.entity.Student;
import com.demo.respository.StudentRepository;

public class StudentServiceImpl implements StudentService{
	
	@Autowired
	StudentRepository studentRepository;

	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}

}
